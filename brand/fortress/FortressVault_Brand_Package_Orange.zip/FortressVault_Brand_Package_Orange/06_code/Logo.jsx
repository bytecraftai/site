// Fortress Vault logo (Bitcoin Orange) — React component
export default function FortressVaultLogo({ height = 40, variant = "gradient", title = "Fortress Vault", ...props }) {
  const fill = variant === "solid" ? "#f7931a" : variant === "white" ? "#ffffff" : "url(#fvOrange)";
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 768" height={height} role="img" aria-label={title} {...props}>
      {variant === "gradient" && (
        <defs>
          <linearGradient id="fvOrange" x1="0" y1="0" x2="0.32" y2="1">
            <stop offset="0%" stopColor="#ffce8a" /><stop offset="38%" stopColor="#f9aa42" />
            <stop offset="64%" stopColor="#f7931a" /><stop offset="100%" stopColor="#ad5f0a" />
          </linearGradient>
        </defs>
      )}
      <path d="M0,0 H240 V240 H0 Z M240,240 A240,240 0 0 0 480,0 H720 V240 A240,240 0 0 0 960,0 H1200 V240 H960 V768 H720 V240 H480 V768 H240 V240 Z" fill={fill} fillRule="evenodd" />
    </svg>
  );
}
