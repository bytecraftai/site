# Fortress Vault — Brand & Logo Spec (Bitcoin Orange)

## The mark
Two-stroke "rr" monogram. Single vector path, `fill-rule: evenodd`. Artwork viewBox `0 0 1200 768`.
Clear space ≥ 25% of mark height; minimum 24 px tall.

## Colors

### Primary — Bitcoin orange
| Token | Hex | Use |
|------|------|-----|
| `--fv-orange`       | `#f7931a` | Primary brand orange (Bitcoin orange) |
| `--fv-orange-300`   | `#ffb24d` | Light orange (hover/highlight) |
| `--fv-orange-200`   | `#ffce8a` | Lightest orange |
| `--fv-orange-deep`  | `#ad5f0a` | Deep orange (gradient end / shadow) |

### Brand gradient (metallic orange) — diagonal top-left → bottom-right (135°)
| Stop | Hex |
|------|------|
| 0%   | `#ffce8a` |
| 38%  | `#f9aa42` |
| 64%  | `#f7931a` |
| 100% | `#ad5f0a` |

### Neutrals
| Token | Hex |
|------|------|
| `--fv-black` | `#050505` |
| `--fv-tile`  | `#0c0c0c` |
| `--fv-border`| `#4a2e12` |
| `--fv-rule`  | `#6e4416` |

## File guide
01_mark · 02_lockups · 03_badges · 04_mobile (1024/512/192/180/167/152/120/80/60 + maskable + orange-tile) · 05_web (favicon + OG) · 06_code.

## Usage
Use the gradient `logo.svg` on dark backgrounds; `logo-solid.svg` for flat single-color. Don't recolor outside the palette.
