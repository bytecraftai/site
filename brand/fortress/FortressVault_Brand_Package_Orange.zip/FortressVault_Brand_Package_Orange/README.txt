FORTRESS VAULT — BRAND PACKAGE (BITCOIN ORANGE)
===============================================
Brand orange: #f7931a   |   Gradient: #ffce8a -> #f9aa42 -> #f7931a -> #ad5f0a (135deg)
Background: #050505      |   Mark viewBox: 0 0 1200 768
Folders: 01_mark · 02_lockups · 03_badges · 04_mobile · 05_web · 06_code  (see 06_code/brand-colors.md)
